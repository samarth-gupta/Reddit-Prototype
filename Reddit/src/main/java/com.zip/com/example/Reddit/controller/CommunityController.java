package com.example.Reddit.controller;

public class CommunityController {
}
