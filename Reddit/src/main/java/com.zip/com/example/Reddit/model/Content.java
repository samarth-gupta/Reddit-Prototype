package com.example.Reddit.model;

import org.hibernate.annotations.Parent;

import javax.persistence.*;

@Entity
@Table(name = "Content")
public class Content{

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Integer id;

    @Column(name = "ParentId")
    private Integer ParentId;

    @Column(name = "ContentBody")
    private String contentbody;

    @Column(name = "ImageURL")
    private String imageurl;

    @Column(name = "Reactions")
    private String reactions;

    @Column(name = "UpVotes")
    private Integer upvotes;

    @Column(name = "DownVotes")
    private Integer downvotes;

    @ManyToOne(fetch=FetchType.LAZY, optional = false)
    @JoinColumn(name = "community_id", nullable = false)
    private Community contentCommunity;

    @ManyToOne(fetch=FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User contentUser;

    public Content() {
    }
}
