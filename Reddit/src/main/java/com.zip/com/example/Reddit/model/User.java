package com.example.Reddit.model;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "Users")
public class User {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @Column(name = "username")
    private String username;

    @Column(name = "First Name")
    private String firstName;

    @Column(name = "Last Name")
    private String lastName;

    @Column(name = "Email")
    private String email;

    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Content> userPosts;

    @ManyToMany(mappedBy = "commUsers")
    private List<Community> userCommunities;

//    @ManyToMany(targetEntity = User.class, mappedBy = "User", fetch = FetchType.EAGER)
//    private List<User> Follows;
//
//    @ManyToOne(fetch=FetchType.LAZY)
//    @JoinColumn(name = "id")
//    private User user;

    public User() {
    }
}
